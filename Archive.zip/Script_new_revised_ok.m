% AGU PUBBLICATIONS
% Geophys Journal International
% Supporting information for 
% The estimation of b-value of the frequency-magnitude distribution and of its one-sigma intervals from binned magnitude data
% Tinti1, P. Gasperini1,2
% 1 Dipartimento di Fisica e Astronomia "Augusto Righi", Università di Bologna, Italy
% 2 Istituto Nazionale di Geofisica e Vulcanologia, Sezione di Bologna, Italy
%
clear all
close all
global beta amu sigm bin nk sum
nset=400000; %number of simulated data for each set
nr=nset;
bin=0.1; % binning size
del=bin/2; % half of the binning size
cto=bin*20; % minimum magnitude difference in trimmed sets
bve=1.; % theoretical b-value
beta=bve*log(10.); % theoretical beta-value
amc0=0; % minimum magnitude of simulation
am1=amc0-del; % minimum magnitude of simulation corrected for binning
amc=0; % minimum cutting magnitude (binned)
s=rng(0);
incomplete=1; % if = 1 include Ogata and Katsura incompleteness
tdepinc=1; % if = 1 include time dependent incompleteness
if(incomplete==1) 
   x0=[amc];
   amu=1; % mean of Normal distribution of Ogata and Katsura incompleteness
   sigm=0.2; % standard deviation of Normal distribution of Ogata and Katsura incompleteness
   mcur=max(amc0,fminunc(@fun,x0))% maximum curvature magnitude
   amc=round((mcur+0.2)/bin)*bin % minimum cutting magnitude (maximum curvature+0.2)
   %amc=round(mcur/bin)*bin % minimum cutting magnitude (maximum curvature)
   %amc=0.4; % minimum cutting magnitude
   pamc=normcdf((amc-amu)/sigm) % completeness rate at the minimum cutting mgnitude
end
nds=0;
nnpos=0;
nneg=0;
sumd=0;
nsumd=0;
nsam=10000; % number of simulated set
while nds<nsam
   nds=nds+1;
   amw= rand(nr,1); % random numbers for magnitude simulation
   amwv3=log(amw)./(-beta)+am1; % simulated magnitudes with GR distribution
   amwv2=round(amwv3./bin).*bin; % binned simulated magnitudes with GR distribution
   if (incomplete==1)
   ppp= rand(nr,1); % random numbers for thinning magnitudes
   p0=normcdf((amwv2-amu)/sigm); % probability of events with time independent completeness
   pi=p0; % time independent incompleteness
   if (tdepinc==1)
      p=1.00; % Omori law exponent
      c=0.01; % Omori law delay
      Te=5; % Sequence ending time
      Ts=0; % sequence starting time
      lt=rand(nr,1); % random numbers for simulation of event times 
      tau(1,1)=-log(1-lt(1,1)); % first simulated inter event time with exponential distribution
      for i=2:nr
          tau(i,1)=tau(i-1,1)-log(1-lt(i,1)); % other simulated inter event times with exponential distribution
      end 
      if(p==1)
          tt=exp(tau.*(log(Te+c)-log(Ts+c))./nr+log(Ts+c))-c; % Omori law times if p=1
      else
          tt=(tau.*((Te+c).^(1-p)-(Ts+c).^(1-p))./nr+(Ts+c).^(1-p)).^(1/(1-p))-c; % Omori law times if p is not =1
      end
      amu1=5.6-4.5-0.75*log10(tt); % time dependent mean magnitude according to Helmstetter et al. (2006) with Mainshock M=4
      p1=normcdf((amwv2-amu1)/sigm); % probability of simulated events with time dependent completeness
      pi=min(p0,p1); % time dependent incompleteness
   end
   nrr=0;
   for j=1:nr
       if(pi(j,1)>ppp(j,1)) % thinning of magnitudes 
           nrr=nrr+1;
           amwv1(nrr,1)=amwv2(j,1);
       end
   end
   else % no incompleteness
       nrr=nr;
       amwv1=amwv2;
   end
    nr=nrr;
    nr1=0;
    ams=0;
    im=0;
    for j=1:nr
        if amwv1(j)>amc || abs(amwv1(j)-amc)<0.0001 % selection of magnitudes larger than minimum threshold amc
            nr1=nr1+1;
            amwv(nr1,1)=amwv1(j,1);
            ams=ams+amwv(nr1,1);
        end
    end
% Bender (1983)
    kk=fix((amwv-amc)./bin+0.0001);  
    nk=max(kk)-min(kk)+1;
    xkk=zeros(nk);
    for j=1:nr1
        xkk(kk(j)+1)=xkk(kk(j)+1)+1;
    end
    sum=0;
    for j=1:nk
       sum=sum+(j-1)*xkk(j);
    end
    sum=sum/nr1;
    warning off
    [bval]=fminunc(@bender,1);
    warning on
    if incomplete==1 % plots
      if nds==1 
         xx=0:0.05 :5;
         yy=fun(xx);
         minyy=min(yy);
         hold off
         %cor=1;
         nr1plot=nr1;
         cor=nr1/11
         semilogy(xx,-yy.*cor)
         hold on
         zz=beta.*exp(-beta.*xx)./(exp(-amu.*beta+(beta.^2.*sigm.^2)/2));
         plot(xx,zz.*cor)
         xlabel('Magnitude','FontSize',14,'Fontweight','bold')
         ylabel('N','FontSize',14,'Fontweight','bold','Rotation',90)
         aa=-1.05:0.1:5.05;
         histogram(amwv1,aa);
         if (tdepinc==1)
            figure
             plot(tt,amu1)
             minamu=min (amu1)
             maxamu=max (amu1)
             tt1=tt(1)
            figure
            amu2=max(amu1,amu);
             for to=1:length(amu2)
                 if to > 1
                     difm(to-1)=amu2(to)-amu2(to-1);
                 end
             tord(to)=to;
             end
             plot (tord,amu2)
             figure
             nnrd=0;
             for d=-1:0.01:0
                 nnrd=nnrd+1;
                 hdifm(nnrd)=0;
                 ddifm(nnrd)=d;
                 for i=1:length(difm)
                     if difm(i)>d-0.05 & difm(i)<=d+0.05
                         hdifm(nnrd)=hdifm(nnrd)+1;
                     end
                 end
             end
             hdifm=log(hdifm);
             plot(ddifm,hdifm)
         end
      end
    end
    nr=nr1;
    ams=ams/nr1; % mean magnitude
    bbend(nds,1)=bval; % b-value using Bender (1983) approach
    bak(nds,1)=1/(log(10)*(ams-amc)); % b-value using Aki (1965) formula 
    ba(nds,1)=1/(log(10)*(ams-amc+del)); % b-value using Aki (1965) formula with Utsu( 1966) correction
    betam=1/(ams-amc+del);
    bbm(nds,1)=1/log(10)/2/del*log((1+betam*del)/(1-betam*del)); % b-value using Marzocchi et al. (2020) correction
    bb(nds,1)=1/log(10)/del*atanh(1/((ams-amc+del)/del)); % b-value using van der Elst (2021) formula for magnitudes
    bbx(nds,1)=1/log(10)/2/del*log((ams-amc+2*del)/(ams-amc)); % b-value Tinti and Gasperini (2022) formula for magnitudes
    erbav(nds,1)=bbx(nds,1)/sqrt(nr); % error using Aki (1965) formula 
    sfm=0.;
    for jj=1:nr
        sfm=sfm+(ams-amwv(jj,1))^2;        
    end
    av(nds,1)=exp(log(10)*bbx(nds,1)*bin);
    bx1v(nds,1)=log((av(nds,1)+sqrt(av(nds,1)/nr1))/(1+sqrt(av(nds,1)/nr1)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for b-value using Tinti and Gasperini (20221) formula for magnitudes
    bx2v(nds,1)=log((av(nds,1)-sqrt(av(nds,1)/nr1))/(1-sqrt(av(nds,1)/nr1)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for b-value using Tinti and Gasperini (20221) formula for magnitudes
    erbxx(nds,1)=(bx2v(nds,1)-bx1v(nds,1))/2;
    erbbv(nds,1)=2.30*bbx(nds,1)^2*sqrt(sfm/nr/(nr-1)); % error using Shi and Bolt (1982) formula for b-value using Tinti and Gasperini (20221) formula for magnitudes
    amaxx(nds)=max(amwv);
    an=0;
    nd=0;
    ad=0;
    np=0;
    ap=0;
    nn=0;
    ane=0;
    nde=0;
    ade=0;
    npe=0;
    ape=0;
    nne=0;
    ane=0;
    ann=0;
    nnn=0;
    anne=0;
    nnne=0;
    anp=0;
    annn=0;
    anpe=0;
    annne=0;
    nnpp=0;
    nnnn=0;
    nnppe=0;
    nnnne=0;
    nnpose=0;
    nnege=0;
    nr2=nr/2;
    for i=1:nr2
        d=amwv(2*i)-amwv(2*i-1); % independent differences
        sumd=sumd+d;
        nsumd=nsumd+1;
        if abs(d)>=cto-0.0001 % trimming (corrected for rounding)
           ad=ad+abs(d); % trimmed absolute differences
           nd=nd+1;
           if d>0
              ap=ap+d; % trimmed positive differences
              np=np+1;
           end
           if d<0
              ann=ann+abs(d); % trimmed negative differences
              nnn=nnn+1;
           end
        end
        an=an+abs(d); % untrimmed absolute differences
        nn=nn+1;
        dv(nn)=abs(d);
        if(d>=0)
           anp=anp+d; % untrimmed non negative differences
           nnpp=nnpp+1;
           nnpos=nnpos+1;
           dpos(nnpos)=d;
        end
        if(d<=0)
           annn=annn+abs(d); % untrimmed non positive difference
           nnnn=nnnn+1;
           nneg=nneg+1;
           dneg(nneg)=abs(d);
        end
    end
    if incomplete==1 % plots
      if nds==1 
         figure
         aa=-1.05:0.1:5.05;
         xx=0:0.05 :5;
         zz=beta.*exp(-beta.*xx)./(exp(-amu.*beta+(beta.^2.*sigm.^2)/2));
         cor=nn/90;
         semilogy(xx,zz.*cor)
         hold on
         xlabel('Magnitude difference','FontSize',14,'Fontweight','bold')
         ylabel('N','Rotation',90,'FontSize',14,'Fontweight','bold')
         histogram(dv,aa);
         nnplot=nn;
         hold off
      end
    end
    for i=1:nr-1
       e=amwv(i+1)-amwv(i); % dependent differences
       if abs(e)>=cto-0.0001
          ade=ade+abs(e); % trimmed absolute differences
          nde=nde+1;
          if e>0
             ape=ape+e; % trimmed positive differences
             npe=npe+1;
             dpose(npe)=e;
          end
          if e<0
             anne=anne+abs(e); % trimmed negative differences
             nnne=nnne+1;
             dnege(nnne)=abs(e);
          end
       end
       ane=ane+abs(e); % untrimmed absolute differences
       nne=nne+1;
       ev(nne)=abs(e);
       if(e>=0)
           anpe=anpe+e; % untrimmed non negative differences
           nnppe=nnppe+1;
           nnpose=nnpose+1;
           dposue(nnpose)=e;
       end
       if(e<=0)
          annne=annne+abs(e); % untrimmed non positive difference
          nnnne=nnnne+1;
          nnege=nnege+1;
          dnegue(nnege)=abs(e);
       end
    end
    amd=ad/nd; % mean of trimmed absolute differences (independent)
    amp=ap/np; % mean of trimmed positive differences (independent)
    amnn=ann/nnn; % mean of trimmed negative differences (independent)
    amde=ade/nde; % mean of trimmed absolute differences (dependent)
    ampe=ape/npe; % mean of trimmed positive differences (dependent)
    amnne=anne/nnne; % mean of trimmed negative differences (dependent)
    amn=an/nn; % mean of untrimmed absolute differences (independent)
    amnpp=anp/nnpp; % mean of untrimmed not negative differences (independent)
    amnnn=annn/nnnn; % mean of untrimmed non positive difference (independent)
    amne=ane/nne; % mean of untrimmed absolute differences (dependent)
    amnppe=anpe/nnppe; % mean of untrimmed not negative differences (dependent)
    amnnne=annne/nnnne; % mean of untrimmed non positive difference (dependent)
    bb1(nds,1)=1/log(10)/del*atanh(1/((amd-cto+del)/del)); % b-value from trimmed absolute differences according to van der Elst (2021)
    bb1b(nds,1)=1/log(10)/2/del*log((amd-cto+2*del)/(amd-cto)); % b-value from trimmed absolute differences according to Tinti and Gasperini (2022)
    bb2(nds,1)=1/log(10)/2/del*log((amp-cto+2*del)/(amp-cto)); % b-value from trimmed positive differences according to Tinti and Gasperini (2022)
    bb2e(nds,1)=1/log(10)/2/del*log((ampe-cto+2*del)/(ampe-cto)); % b-value from trimmed positive differences according to Tinti and Gasperini (2022)
    bb4(nds,1)=1/log(10)/2/del*log((amnn-cto+2*del)/(amnn-cto)); % b-value from trimmed negative differences according to Tinti and Gasperini (2022)
    bb4e(nds,1)=1/log(10)/2/del*log((amnne-cto+2*del)/(amnne-cto)); % b-value from trimmed negative differences according to Tinti and Gasperini (2022)
    bb3(nds,1)=1/log(10)/del/2.*asinh(1/((amn)/del/2.)); % b-value from untrimmed -absolute differences according to van der Elst (2021)
    bb3t(nds,1)=1/log(10)/2/del*log((2*del+sqrt(4*del^2+amn^2))/amn); % b-value from untrimmed absolute differences according to Tinti and Gasperini (2022)
    bb3tp(nds,1)=1/log(10)/del*atanh(1/((amnpp+del)/del)); % b-value from untrimmed non negative differences according to van der Elst (2021)
    bb3tn(nds,1)=1/log(10)/del*atanh(1/((amnnn+del)/del)); % b-value from untrimmed non positive differences according to van der Elst (2021)
    bb1e(nds,1)=1/log(10)/del*atanh(1/((amde-cto+del)/del)); % b-value from trimmed absolute differences (dependent) according to van der Elst (2021)
    bb1eb(nds,1)=1/log(10)/2/del*log((amde-cto+2*del)/(amde-cto)); % b-value from trimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
    bb3e(nds,1)=1/log(10)/del/2.*asinh(1/((amne)/del/2.)); % b-value from untrimmed absolute differences (dependent) according to van der Elst (2021)
    bb3et(nds,1)=1/log(10)/2/del*log((2*del+sqrt(4*del^2+amne^2))/amne); % b-value from untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
    bb3ept(nds,1)=1/log(10)/2/del*log((amnppe+2*del)/(amnppe)); % b-value from untrimmed non negative differences (dependent) according to Tinti and Gasperini (2022)
%    bb3ept(nds,1)=1/log(10)/del*atanh(1/((amnppe+del)/del)); % b-value from untrimmed non negative differences (dependent) according to Tinti and Gasperini (2022)
%    bb3ept(nds,1)=1/log(10)/2/del*log((2*del+sqrt(4*del^2+amnppe^2))/amnppe); % b-value from untrimmed non negative differences (dependent) according to Tinti and Gasperini (2022)
    bb3ent(nds,1)=1/log(10)/2/del*log((amnnne+2*del)/(amnnne)); % b-value from untrimmed non positive differences (dependent) according to Tinti and Gasperini (2022)
%    bb3ent(nds,1)=1/log(10)/del*atanh(1/((amnnne-cto+del)/del)); % b-value from untrimmed non positive differences (dependent) according to Tinti and Gasperini (2022)
%    bb3ent(nds,1)=1/log(10)/2/del*log((2*del+sqrt(4*del^2+amnnne^2))/amnnne); % b-value from untrimmed non positive differences (dependent) according to Tinti and Gasperini (2022)
    nr=nset;
    av2(nds,1)=exp(log(10)*bb1b(nds,1)*bin);
    bx1v2(nds,1)=log((av2(nds,1)+sqrt(av2(nds,1)/nd))/(1+sqrt(av2(nds,1)/nd)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for trimmed absolute differences according to Tinti and Gasperini (2022
    bx2v2(nds,1)=log((av2(nds,1)-sqrt(av2(nds,1)/nd))/(1-sqrt(av2(nds,1)/nd)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for trimmed absolute differences according to Tinti and Gasperini (2022
    av2a(nds,1)=exp(log(10)*bb2(nds,1)*bin);
    bx1b2(nds,1)=log((av2a(nds,1)+sqrt(av2a(nds,1)/np))/(1+sqrt(av2a(nds,1)/np)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for trimmed positive differences according to Tinti and Gasperini (2022) (eq. 17)
    bx2b2(nds,1)=log((av2a(nds,1)-sqrt(av2a(nds,1)/np))/(1-sqrt(av2a(nds,1)/np)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for trimmed positive differences according to Tinti and Gasperini (2022) (eq. 17)   
    av4a(nds,1)=exp(log(10)*bb4(nds,1)*bin);
    bx1b4(nds,1)=log((av4a(nds,1)+sqrt(av4a(nds,1)/nnn))/(1+sqrt(av4a(nds,1)/nnn)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for trimmed positive differences according to Tinti and Gasperini (2022) (eq. 17)
    bx2b4(nds,1)=log((av4a(nds,1)-sqrt(av4a(nds,1)/nnn))/(1-sqrt(av4a(nds,1)/nnn)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for trimmed positive differences according to Tinti and Gasperini (2022) (eq. 17)   
    av2b(nds,1)=exp(log(10)*bb2e(nds,1)*bin);
    bx1b2e(nds,1)=log((av2b(nds,1)+sqrt(av2b(nds,1)/npe))/(1+sqrt(av2b(nds,1)/npe)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for trimmed positive differences according to Tinti and Gasperini (2022) (eq. 16)
    bx2b2e(nds,1)=log((av2b(nds,1)-sqrt(av2b(nds,1)/npe))/(1-sqrt(av2b(nds,1)/npe)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for trimmed positive differences according to Tinti and Gasperini (2022) (eq. 16)
    av4b(nds,1)=exp(log(10)*bb4e(nds,1)*bin);
    bx1b4e(nds,1)=log((av4b(nds,1)+sqrt(av4b(nds,1)/nnne))/(1+sqrt(av4b(nds,1)/nnne)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for trimmed positive differences according to Tinti and Gasperini (2022) (eq. 16)
    bx2b4e(nds,1)=log((av4b(nds,1)-sqrt(av4b(nds,1)/nnne))/(1-sqrt(av4b(nds,1)/nnne)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for trimmed positive differences according to Tinti and Gasperini (2022) (eq. 16)
    av1(nds,1)=exp(log(10)*bb1eb(nds,1)*bin);
    bx1v1(nds,1)=log((av1(nds,1)+sqrt(av1(nds,1)/nde))/(1+sqrt(av1(nds,1)/nde)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for trimmed absolute differences (dependent) according to Tinti and Gasperini (2022
    bx2v1(nds,1)=log((av1(nds,1)-sqrt(av1(nds,1)/nde))/(1-sqrt(av1(nds,1)/nde)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for trimmed absolute differences (dependent) according to Tinti and Gasperini (2022
    av3(nds,1)=exp(log(10)*bb3t(nds,1)*bin);
    bx1v3(nds,1)=log((av3(nds,1)+sqrt(av3(nds,1)/nn))/(1+sqrt(av3(nds,1)/nn)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences according to van der Elst (2021)
    bx2v3(nds,1)=log((av3(nds,1)-sqrt(av3(nds,1)/nn))/(1-sqrt(av3(nds,1)/nn)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences according to van der Elst (2021)
    av3p(nds,1)=exp(log(10)*bb3tp(nds,1)*bin);
    bx1v3p(nds,1)=log((av3p(nds,1)+sqrt(av3p(nds,1)/nnpp))/(1+sqrt(av3p(nds,1)/nnpp)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for untrimmed non negative differences according to van der Elst (2021)
    bx2v3p(nds,1)=log((av3p(nds,1)-sqrt(av3p(nds,1)/nnpp))/(1-sqrt(av3p(nds,1)/nnpp)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for untrimmed non negative differences according to van der Elst (2021)
    av3n(nds,1)=exp(log(10)*bb3tn(nds,1)*bin);
    bx1v3n(nds,1)=log((av3n(nds,1)+sqrt(av3n(nds,1)/nnnn))/(1+sqrt(av3n(nds,1)/nnnn)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for untrimmed non positive differences according to van der Elst (2021)
    bx2v3n(nds,1)=log((av3n(nds,1)-sqrt(av3n(nds,1)/nnnn))/(1-sqrt(av3n(nds,1)/nnnn)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for untrimmed non positive differences according to van der Elst (2021)

    av3pe(nds,1)=exp(log(10)*bb3ept(nds,1)*bin);
    bx1v3pe(nds,1)=log((av3pe(nds,1)+sqrt(av3pe(nds,1)/nnppe))/(1+sqrt(av3pe(nds,1)/nnppe)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for untrimmed non negative differences according to van der Elst (2021)
    bx2v3pe(nds,1)=log((av3pe(nds,1)-sqrt(av3pe(nds,1)/nnppe))/(1-sqrt(av3pe(nds,1)/nnppe)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for untrimmed non negative differences according to van der Elst (2021)
    av3ne(nds,1)=exp(log(10)*bb3ent(nds,1)*bin);
    bx1v3ne(nds,1)=log((av3ne(nds,1)+sqrt(av3ne(nds,1)/nnnne))/(1+sqrt(av3ne(nds,1)/nnnne)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for untrimmed non positive differences according to van der Elst (2021)
    bx2v3ne(nds,1)=log((av3ne(nds,1)-sqrt(av3ne(nds,1)/nnnne))/(1-sqrt(av3ne(nds,1)/nnnne)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for untrimmed non positive differences according to van der Elst (2021)
    
    av4(nds,1)=exp(log(10)*bb3et(nds,1)*bin);
    bx1v4(nds,1)=log((av4(nds,1)+sqrt(av4(nds,1)/nne))/(1+sqrt(av4(nds,1)/nne)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
    bx2v4(nds,1)=log((av4(nds,1)-sqrt(av4(nds,1)/nne))/(1-sqrt(av4(nds,1)/nne)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
    av5(nds,1)=2*del*log(10)*bb3t(nds,1);
    cschalp=csch(av5(nds,1))*(1+sqrt(cosh(av5(nds,1))/nn));
    cschalm=csch(av5(nds,1))*(1-sqrt(cosh(av5(nds,1))/nn));
    bx1v5(nds,1)=log((1+sqrt(1+cschalp^2))/cschalp)/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
    bx2v5(nds,1)=log((1+sqrt(1+cschalm^2))/cschalm)/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
    av6(nds,1)=2*del*log(10)*bb3et(nds,1);  
    cschalp=csch(av6(nds,1))*(1+sqrt(cosh(av6(nds,1))/nne));
    cschalm=csch(av6(nds,1))*(1-sqrt(cosh(av6(nds,1))/nne));
    bx1v6(nds,1)=log((1+sqrt(1+cschalp^2))/cschalp)/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
    bx2v6(nds,1)=log((1+sqrt(1+cschalm^2))/cschalm)/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
    nrv(nds,1)=nr; % number of magnitude data
    nr1v(nds,1)=nr1; % number of magnitude data
    ndv(nds,1)=nd; % number of trimmed absolute magnitude differences 
    npv(nds,1)=np; % number of trimmed positive magnitude differences 
    nnnv(nds,1)=nnn; % number of trimmed negative magnitude differences 
    nnv(nds,1)=nn; % number of untrimmed absolute magnitude differences
    ndev(nds,1)=nde; % number of trimmed absolute magnitude differences (dependent)
    npev(nds,1)=npe; % number of trimmed positive magnitude differences (dependent)
    nnnev(nds,1)=nnne; % number of trimmed negative magnitude differences (dependent)
    nnev(nds,1)=nne; % number of untrimmed absolute magnitude differences (dependent)
    nnppv(nds,1)=nnpp; % number of untrimmed positive magnitude differences 
    nnnnv(nds,1)=nnnn; % number of untrimmed negative magnitude differences 
end
baa=mean(ba); % mean b-value using Aki (1965) formula with Utsu( 1966) correction
erba=std(ba); % std of b-value using Aki (1965) formula with Utsu( 1966) correction
erba2=mean(erbbv); % mean error using Shi and Bolt (1982) formula for b-value using Tinti and Gasperini (20221) formula for magnitudes
pa=min(length(find(ba(:)>bve))/length(find(ba(:)>baa)),length(find(ba(:)<bve))/length(find(ba(:)<baa)));
bbbe=mean(bbend); % mean b-value using Bender (1983) approach
erbbe=std(bbend);% std of b-value using Bender (1983) approach
baak=mean(bak); % mean b-value using Aki (1965) formula 
erbak=std(bak); % std of b-value using Aki (1965) formula 
pak=min(length(find(bak(:)>bve))/length(find(bak(:)>baak)),length(find(bak(:)<bve))/length(find(bak(:)<baak)));
pbe=min(length(find(bbend(:)>bve))/length(find(bbend(:)>bbbe)),length(find(bbend(:)<bve))/length(find(bbend(:)<bbbe)));
eraki2=mean(erbav); % mean error using Aki (1965) formula 
bm=mean(bbm); % mean b-value using Marzocchi et al. (2020) correction
erbm=std(bbm);% std of b-value using Marzocchi et al. (2020) correction
pbm=min(length(find(bbm(:)>bve))/length(find(bbm(:)>bm)),length(find(bbm(:)<bve))/length(find(bbm(:)<bm)));
b=mean(bb); % mean b-value using van der Elst (2021) formula for magnitudes
erb=std(bb); % std of b-value using van der Elst (2021) formula for magnitudes
pb=min(length(find(bb(:)>bve))/length(find(bb(:)>b)),length(find(bb(:)<bve))/length(find(bb(:)<b)));
bx=mean(bbx); % mean  b-value using Tinti and Gasperini (2022) formula for magnitudes
erbx=std(bbx); % std of b-value using Tinti and Gasperini (2022) formula for magnitudes
ppx=min(length(find(bbx(:)>bve))/length(find(bbx(:)>bx)),length(find(bbx(:)<bve))/length(find(bbx(:)<bx)));
bx1=mean(bx1v); % upper confidence limit according to Tinti and Gasperini (2022) for b-value using Tinti and Gasperini (20221) formula for magnitudes 
bx2=mean(bx2v); % lower confidence limit according to Tinti and Gasperini (2022) for b-value using Tinti and Gasperini (20221) formula for magnitudes 
b1=mean(bb1); % mean b-value from trimmed absolute differences according to van der Elst (2021)
erb1=std(bb1); % std of b-value from trimmed absolute differences according to van der Elst (2021)
pp1=min(length(find(bb1(:)>bve))/length(find(bb1(:)>b1)),length(find(bb1(:)<bve))/length(find(bb1(:)<b1)));
pb2=min(length(find(bb1(:)>bve))/length(find(bb1(:)>b1)),length(find(bb1(:)<bve))/length(find(bb1(:)<b1)));
b1b=mean(bb1b); % mean b-value from trimmed absolute differences according to Tinti and Gasperini (2022)
erb1b=std(bb1b); % std of b-value from trimmed absolute differences according to Tinti and Gasperini (2022)
pp1b=min(length(find(bb1b(:)>bve))/length(find(bb1b(:)>b1b)),length(find(bb1b(:)<bve))/length(find(bb1b(:)<b1b)));
bx1v1a=mean(bx1v2); % mean of upper confidence limit according to Tinti and Gasperini (2022) for trimmed absolute differences according to Tinti and Gasperini (2022
bx2v1a=mean(bx2v2); % mean of lower confidence limit according to Tinti and Gasperini (2022) for trimmed absolute differences according to Tinti and Gasperini (2022
bx1b2a=mean(bx1b2); % mean of upper confidence limit according to Tinti and Gasperini (2022) for trimmed positive differences according to Tinti and Gasperini (2022
bx2b2a=mean(bx2b2); % mean of lower confidence limit according to Tinti and Gasperini (2022) for trimmed positive differences according to Tinti and Gasperini (2022
bx1b4a=mean(bx1b4); % mean of upper confidence limit according to Tinti and Gasperini (2022) for trimmed negative differences according to Tinti and Gasperini (2022
bx2b4a=mean(bx2b4); % mean of lower confidence limit according to Tinti and Gasperini (2022) for trimmed negative differences according to Tinti and Gasperini (2022
bx1v1b=mean(bx1v1); % mean of upper confidence limit according to Tinti and Gasperini (2022) for trimmed absolute differences (dependent) according to Tinti and Gasperini (2022
bx2v1b=mean(bx2v1); % mean of lower confidence limit according to Tinti and Gasperini (2022) for trimmed absolute differences (dependent) according to Tinti and Gasperini (2022
bx1b2ea=mean(bx1b2e); % mean of upper confidence limit according to Tinti and Gasperini (2022) for trimmed positive differences (dependent) according to Tinti and Gasperini (2022
bx2b2ea=mean(bx2b2e); % mean of lower confidence limit according to Tinti and Gasperini (2022) for trimmed positive differences (dependent) according to Tinti and Gasperini (2022
bx1b4ea=mean(bx1b4e); % mean of upper confidence limit according to Tinti and Gasperini (2022) for trimmed negative differences (dependent) according to Tinti and Gasperini (2022
bx2b4ea=mean(bx2b4e); % mean of lower confidence limit according to Tinti and Gasperini (2022) for trimmed negative differences (dependent) according to Tinti and Gasperini (2022
bx1v3b=mean(bx1v3); % mean of upper confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences according to van der Elst (2021)
bx2v3b=mean(bx2v3); % mean of lower confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences according to van der Elst (2021)
bx1v3bp=mean(bx1v3p); % mean of upper confidence limit according to Tinti and Gasperini (2022) for untrimmed positive differences according to van der Elst (2021)
bx2v3bp=mean(bx2v3p); % mean of lower confidence limit according to Tinti and Gasperini (2022) for untrimmed positive differences according to van der Elst (2021)
bx1v3bn=mean(bx1v3n); % mean of upper confidence limit according to Tinti and Gasperini (2022) for untrimmed negative differences according to van der Elst (2021)
bx2v3bn=mean(bx2v3n); % mean of lower confidence limit according to Tinti and Gasperini (2022) for untrimmed negative differences according to van der Elst (2021)

bx1v3bpe=mean(bx1v3pe); % mean of upper confidence limit according to Tinti and Gasperini (2022) for untrimmed positive differences according to van der Elst (2021)
bx2v3bpe=mean(bx2v3pe); % mean of lower confidence limit according to Tinti and Gasperini (2022) for untrimmed positive differences according to van der Elst (2021)
bx1v3bne=mean(bx1v3ne); % mean of upper confidence limit according to Tinti and Gasperini (2022) for untrimmed negative differences according to van der Elst (2021)
bx2v3bne=mean(bx2v3ne); % mean of lower confidence limit according to Tinti and Gasperini (2022) for untrimmed negative differences according to van der Elst (2021)

bx1v4b=mean(bx1v4); % mean of upper confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
bx2v4b=mean(bx2v4); % mean of lower confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
bx1v5b=mean(bx1v5); % mean of upper confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences according to Tinti and Gasperini (2022)
bx2v5b=mean(bx2v5); % mean of lower confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences according to Tinti and Gasperini (2022)
bx1v6b=mean(bx1v6); % mean of upper confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
bx2v6b=mean(bx2v6); % mean of lower confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
b2=mean(bb2); % mean of b-value from trimmed positive differences according to Tinti and Gasperini (2022)
erb2=std(bb2); % std of b-value from trimmed positive differences according to Tinti and Gasperini (2022)
pp2=min(length(find(bb2(:)>bve))/length(find(bb2(:)>b2)),length(find(bb2(:)<bve))/length(find(bb2(:)<b2)));
b2e=mean(bb2e); % mean of b-value from trimmed positive differences according to Tinti and Gasperini (2022)
erb2e=std(bb2e); % std of b-value from trimmed positive differences according to Tinti and Gasperini (2022)
pp2e=min(length(find(bb2e(:)>bve))/length(find(bb2e(:)>b2e)),length(find(bb2e(:)<bve))/length(find(bb2e(:)<b2e)));
b3=mean(bb3); % mean of % b-value from untrimmed absolute differences according to van der Elst (2021)
erb3=std(bb3); % std of % b-value from untrimmed absolute differences according to van der Elst (2021)
pp3=min(length(find(bb3(:)>bve))/length(find(bb3(:)>b3)),length(find(bb3(:)<bve))/length(find(bb3(:)<b3)));
b4=mean(bb4); % mean of b-value from trimmed negative differences according to Tinti and Gasperini (2022)
erb4=std(bb4); % std of b-value from trimmed negative differences according to Tinti and Gasperini (2022)
pp4=min(length(find(bb4(:)>bve))/length(find(bb4(:)>b4)),length(find(bb4(:)<bve))/length(find(bb4(:)<b4)));
b4e=mean(bb4); % mean of b-value from trimmed negative differences according to Tinti and Gasperini (2022)
erb4e=std(bb4e); % std of b-value from trimmed negative differences according to Tinti and Gasperini (2022)
pp4e=min(length(find(bb4e(:)>bve))/length(find(bb4e(:)>b4e)),length(find(bb4e(:)<bve))/length(find(bb4e(:)<b4e)));
b3t=mean(bb3t); % mean of b-value from untrimmed absolute differences according to Tinti and Gasperini (2022)
erb3t=std(bb3t); % std of b-value from untrimmed absolute differences according to Tinti and Gasperini (2022)
pp3t=min(length(find(bb3t(:)>bve))/length(find(bb3t(:)>b3t)),length(find(bb3t(:)<bve))/length(find(bb3t(:)<b3t)));
b3tp=mean(bb3tp); % mean of b-value from untrimmed non negative differences according to van der Elst (2021)
erb3tp=std(bb3tp); % std of b-value from untrimmed non negative differences according to van der Elst (2021)
pp3tp=min(length(find(bb3tp(:)>bve))/length(find(bb3tp(:)>b3tp)),length(find(bb3tp(:)<bve))/length(find(bb3tp(:)<b3tp)));
b3tn=mean(bb3tn); % mean of b-value from untrimmed non positive differences according to van der Elst (2021)
erb3tn=std(bb3tn); % std of b-value from untrimmed non positive differences according to van der Elst (2021)
pp3tn=min(length(find(bb3tn(:)>bve))/length(find(bb3tn(:)>b3tn)),length(find(bb3tn(:)<bve))/length(find(bb3tn(:)<b3tn)));
b1e=mean(bb1e); % mean of b-value from trimmed absolute differences (dependent) according to van der Elst (2021)
erb1e=std(bb1e); % std of b-value from trimmed absolute differences (dependent) according to van der Elst (2021)
pp1e=min(length(find(bb1e(:)>bve))/length(find(bb1e(:)>b1e)),length(find(bb1e(:)<bve))/length(find(bb1e(:)<b1e)));
b1eb=mean(bb1eb); % mean of b-value from trimmed absolute differences (dependent) according to Tinti and Gasperini (2022
erb1eb=std(bb1eb); % std of b-value from trimmed absolute differences (dependent) according to Tinti and Gasperini (2022
pp1eb=min(length(find(bb1eb(:)>bve))/length(find(bb1eb(:)>b1eb)),length(find(bb1eb(:)<bve))/length(find(bb1eb(:)<b1eb)));
b3e=mean(bb3e); % mean of b-value from untrimmed absolute differences (dependent) according to van der Elst (2021)
erb3e=std(bb3e); % std of b-value from untrimmed absolute differences (dependent) according to van der Elst (2021)
pp3e=min(length(find(bb3e(:)>bve))/length(find(bb3e(:)>b3e)),length(find(bb3e(:)<bve))/length(find(bb3e(:)<b3e)));
b3et=mean(bb3et); % mean of b-value from untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
erb3et=std(bb3et); % std of b-value from untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
pp3et=min(length(find(bb3et(:)>bve))/length(find(bb3et(:)>b3et)),length(find(bb3et(:)<bve))/length(find(bb3et(:)<b3et)));
b3ept=mean(bb3ept); % mean of b-value from untrimmed non negative differences (dependent) according to Tinti and Gasperini (2022)
erb3ept=std(bb3ept); % std of b-value from untrimmed non negative differences (dependent) according to Tinti and Gasperini (2022)
pp3ept=min(length(find(bb3ept(:)>bve))/length(find(bb3ept(:)>b3ept)),length(find(bb3ept(:)<bve))/length(find(bb3ept(:)<b3ept)));
b3ent=mean(bb3ent); % mean of b-value from untrimmed non positive differences (dependent) according to Tinti and Gasperini (2022)
erb3ent=std(bb3ent); % std of b-value from untrimmed non positive differences (dependent) according to Tinti and Gasperini (2022)
pp3ent=min(length(find(bb3ent(:)>bve))/length(find(bb3ent(:)>b3ent)),length(find(bb3ent(:)<bve))/length(find(bb3ent(:)<b3ent)));
nr1=round(mean(nr1v)); % mean of number of magnitude data
nr=round(mean(nrv)); % mean of number of magnitude data
nd=round(mean(ndv)); % mean of number of trimmed absolute magnitude differences 
np=round(mean(npv)); % mean of number of trimmed positive magnitude differences 
nn=round(mean(nnv)); % mean of number of untrimmed absolute magnitude differences
nde=round(mean(ndev)); % mean of number of trimmed absolute magnitude differences (dependent
npe=round(mean(npev)); % mean of number of trimmed positive magnitude differences (dependent)
nnne=round(mean(nnnev)); % mean of number of trimmed negative magnitude differences (dependent)
nne=round(mean(nnev)); % mean of number of untrimmed absolute magnitude differences (dependent)
nnpp=round(mean(nnppv)); % mean of number of untrimmed positive magnitude differences 
nnnn=round(mean(nnnnv)); % mean of number of untrimmed negative magnitude differences 
meand=sumd/nsumd;
nsumd;
if incomplete == 1 & tdepinc ==1
    figure
    lep=length(dpose);
    len=length(dnege);
    ll=0;
    for d=0:0.1:10
        ll=ll+1;
        x(ll)=d;      
        ddpos(ll)=0;
        for j=1:lep
            if abs(dpose(j)-d)<0.001
                ddpos(ll)=ddpos(ll)+1;
            end
        end
        ddneg(ll)=0;
        for j=1:len
            if abs(dnege(j)-d)<0.001
                ddneg(ll)=ddneg(ll)+1;
            end
        end
    end
    ddpos=log10(ddpos);
    ddneg=log10(ddneg);
    plot(x,ddpos)
    hold on
    plot(x,ddneg)
    hold off
end
X=sprintf('Author             method      mean b    std      N      p');
disp(X)
warning('off','all');
[h,p]=lillietest(bak);
warning('on','all');
% mean b-value, std b-value, mean n data, p, mean error Aki
X=sprintf('Aki               mag         %f %f %i %f %f %f %f',baak,erbak,nr1,pak,eraki2);
disp(X)
tab(1,1)=baak;
tab(1,2)=erbak;
tab(1,3)=nr1;
tab(1,4)=pak;
tab1(1,1)=baak;
tab1(1,2)=erbak;
tab1(1,3)=nr1;
tab1(1,4)=pak;
tab2(1,1)=baak;
tab2(1,2)=erbak;
tab2(1,3)=nr1;
tab2(1,4)=pak;
% mean b-value, std b-value, mean n data, p 
X=sprintf('Aki,Utsu          mag         %f %f %i %f',baa,erba,nr1,pa);
disp(X)
% mean b-value, std b-value, mean n data, p 
X=sprintf('Bender            mag         %f %f %i %f',bbbe,erbbe,nr1,pbe);
disp(X)
tab(2,1)=baa;
tab(2,2)=erba;
tab(2,3)=nr1;
tab(2,4)=pa;
tab(3,1)=bbbe;
tab(3,2)=erbbe;
tab(3,3)=nr1;
tab(3,4)=pbe;
tab1(2,1)=baa;
tab1(2,2)=erba;
tab1(2,3)=nr1;
tab1(2,4)=pa;
tab1(3,1)=bbbe;
tab1(3,2)=erbbe;
tab1(3,3)=nr1;
tab1(3,4)=pbe;
tab2(2,1)=baa;
tab2(2,2)=erba;
tab2(2,3)=nr1;
tab2(2,4)=pa;
tab2(3,1)=bbbe;
tab2(3,2)=erbbe;
tab2(3,3)=nr1;
tab2(3,4)=pbe;
% mean b-value, std b-value, mean n data, p
X=sprintf('van der Elst      mag         %f %f %i %f',b,erb, nr1,pbm);
disp(X)
taber(1,1)=bve;
taber(1,2)=nr1;
taber(1,3)=bx;
taber(1,4)=erbx;
taber(1,5)=eraki2;
taber(1,6)=erba2;
taber(1,7)=bx-bx1;
taber(1,8)=bx2-bx;
taber(1,9)=(bx2-bx1)/2;
% mean b-value, std b-value, mean n data, p 
X=sprintf('Marzocchi et al.  mag         %f %f %i %f',bm,erbm, nr1,pbm);
disp(X)
% mean b-value, std b-value, mean n data, p, mean err Aki, mean err Shi and
% Bolt, errmin, errmax, errmean (this work)
X=sprintf('Tinti & Gasperini mag         %f %f %i %f %f %f %f %f %f',bx,erbx, nr1, ppx, eraki2, erba2, bx-bx1, bx2-bx, (bx2-bx1)/2);
disp(X)
tab(4,1)=bx;
tab(4,2)=erbx;
tab(4,3)=nr1;
tab(4,4)=ppx;
tab1(4,1)=bx;
tab1(4,2)=erbx;
tab1(4,3)=nr1;
tab1(4,4)=ppx;
tab2(4,1)=bx;
tab2(4,2)=erbx;
tab2(4,3)=nr1;
tab2(4,4)=ppx;
% mean b-value, std b-value, mean n data, p 
X=sprintf('van der Elst      abs trim 16 %f %f %i %f',b1e,erb1e,nde,pp1e);
disp(X)
X=sprintf('van der Elst      abs trim 17 %f %f %i %f',b1,erb1,nd,pp1);
disp(X)
taber2(1,1)=bve;
taber2(1,2)=16;
taber2(1,3)=nde;
taber2(1,4)=b1eb;
taber2(1,5)=erb1eb;
taber2(1,6)=b1eb-bx1v1b;
taber2(1,7)=bx2v1b-b1eb;
taber2(1,8)=(bx2v1b-bx1v1b)/2;
taber2(2,1)=bve;
taber2(2,2)=17;
taber2(2,3)=nd;
taber2(2,4)=b1b;
taber2(2,5)=erb1b;
taber2(2,6)=b1b-bx1v1a;
taber2(2,7)=bx2v1a-b1b;
taber2(2,8)=(bx2v1a-bx1v1a)/2;
% mean b-value, std b-value, mean n data, p, lower conf interval, upper conf interval, mean conf interval
X=sprintf('Tinti & Gasperini abs trim 16 %f %f %i %f %f %f %f',b1eb,erb1eb,nde,pp1eb,b1eb-bx1v1b,bx2v1b-b1eb,(bx2v1b-bx1v1b)/2);
disp(X)
X=sprintf('Tinti & Gasperini abs trim 17 %f %f %i %f %f %f %f',b1b,erb1b,nd,pp1b,b1b-bx1v1a,bx2v1a-b1b,(bx2v1a-bx1v1a)/2);
disp(X)
tabe(1,1)=b1eb;
tabe(1,2)=erb1eb;
tabe(1,3)=nde;
tabe(1,4)=pp1eb;
tab(7,1)=b1eb;
tab(7,2)=erb1eb;
tab(7,3)=nde;
tab(7,4)=pp1eb;
tab(8,1)=b1b;
tab(8,2)=erb1b;
tab(8,3)=nd;
tab(8,4)=pp1b;
tab1(6,1)=b1b;
tab1(6,2)=erb1b;
tab1(6,3)=nd;
tab1(6,4)=pp1b;
tab2(6,1)=b1b;
tab2(6,2)=erb1b;
tab2(6,3)=nd;
tab2(6,4)=pp1b;
% mean b-value, std b-value, mean n data, p 
X=sprintf('Tinti & Gasperini pos trim 16 %f %f %i %f',b2e,erb2e,npe,pp2e);
disp(X)
X=sprintf('Tinti & Gasperini pos trim 17 %f %f %i %f',b2,erb2,np,pp2);
disp(X)
tabe(2,1)=b2e;
tabe(2,2)=erb2e;
tabe(2,3)=npe;
tabe(2,4)=pp2e;
tab2e=tab2;
tab2(7,1)=b2;
tab2(7,2)=erb2;
tab2(7,3)=np;
tab2(7,4)=pp2;
tab2e(7,1)=b2e;
tab2e(7,2)=erb2e;
tab2e(7,3)=npe;
tab2e(7,4)=pp2e;
taber2(3,1)=bve;
taber2(3,2)=16;
taber2(3,3)=npe;
taber2(3,4)=b2e;
taber2(3,5)=erb2e;
taber2(3,6)=b2e-bx1b2ea;
taber2(3,7)=bx2b2ea-b2e;
taber2(3,8)=(bx2b2ea-bx1b2ea)/2;
taber2(4,1)=bve;
taber2(4,2)=17;
taber2(4,3)=np;
taber2(4,4)=b2;
taber2(4,5)=erb2;
taber2(4,6)=b2-bx1b2a;
taber2(4,7)=bx2b2a-b2;
taber2(4,8)=(bx2b2a-bx1b2a)/2;
% mean b-value, std b-value, mean n data, p 
X=sprintf('Tinti & Gasperini neg trim 16 %f %f %i %f',b4e,erb4e,nnne,pp4e);
disp(X)
X=sprintf('Tinti & Gasperini neg trim 17 %f %f %i %f',b4,erb4,nnn,pp4);
disp(X)
tabe(3,1)=b4e;
tabe(3,2)=erb4e;
tabe(3,3)=nnne;
tabe(3,4)=pp4e;
tab2(8,1)=b4;
tab2(8,2)=erb4;
tab2(8,3)=nnn;
tab2(8,4)=pp4;
tab2e(8,1)=b4e;
tab2e(8,2)=erb4e;
tab2e(8,3)=nnne;
tab2e(8,4)=pp4e;
taber2(5,1)=bve;
taber2(5,2)=16;
taber2(5,3)=nnne;
taber2(5,4)=b4e;
taber2(5,5)=erb4e;
taber2(5,6)=b4e-bx1b4ea;
taber2(5,7)=bx2b4ea-b4e;
taber2(5,8)=(bx2b4ea-bx1b4ea)/2;
taber2(6,1)=bve;
taber2(6,2)=17;
taber2(6,3)=nnn;
taber2(6,4)=b4;
taber2(6,5)=erb4;
taber2(6,6)=b4-bx1b4a;
taber2(6,7)=bx2b4a-b4;
taber2(6,8)=(bx2b4a-bx1b4a)/2;
% mean b-value, std b-value, mean n data, p 
X=sprintf('van der Elst      abs      16 %f %f %i %f',b3e,erb3e,nne,pp3e);
disp(X)
X=sprintf('van der Elst      abs      17 %f %f %i %f',b3,erb3,nn,pp3);
disp(X)
taber3(1,1)=bve;
taber3(1,2)=16;
taber3(1,3)=nne;
taber3(1,4)=b3et;
taber3(1,5)=erb3et;
taber3(1,6)=b3et-bx1v6b;
taber3(1,7)=bx2v6b-b3et;
taber3(1,8)=(bx2v6b-bx1v6b)/2;
taber3(2,1)=bve;
taber3(2,2)=17;
taber3(2,3)=nn;
taber3(2,4)=b3t;
taber3(2,5)=erb3t;
taber3(2,6)=b3t-bx1v5b;
taber3(2,7)=bx2v5b-b3t;
taber3(2,8)=(bx2v5b-bx1v5b)/2;
% mean b-value (dependent), std b-value (dependent), mean n data (dependent), p (dependent), lower conf interval (dependent), upper conf interval (dependent), mean conf interval (dependent)
X=sprintf('Tinti & Gasperini abs      16 %f %f %i %f %f %f %f',b3et,erb3et,nne,pp3et,b3et-bx1v6b,bx2v6b-b3et,(bx2v6b-bx1v6b)/2);
disp(X)
% mean b-value, std b-value, mean n data, p, lower conf interval, upper conf interval, mean conf interval
X=sprintf('Tinti & Gasperini abs      17 %f %f %i %f %f %f %f',b3t,erb3t,nn,pp3t,b3t-bx1v5b,bx2v5b-b3t,(bx2v5b-bx1v5b)/2);
disp(X)
taber3(3,1)=bve;
taber3(3,2)=16;
taber3(3,3)=nnppe;
taber3(3,4)=b3ept;
taber3(3,5)=erb3ept;
taber3(3,6)=b3ept-bx1v3bpe;
taber3(3,7)=bx2v3bpe-b3ept;
taber3(3,8)=(bx2v3bpe-bx1v3bpe)/2;
taber3(4,1)=bve;
taber3(4,2)=17;
taber3(4,3)=nnpp;
taber3(4,4)=b3tp;
taber3(4,5)=erb3tp;
taber3(4,6)=b3tp-bx1v3bp;
taber3(4,7)=bx2v3bp-b3tp;
taber3(4,8)=(bx2v3bp-bx1v3bp)/2;
% mean b-value, std b-value, mean n data, p,  lower conf interval, upper conf interval, mean conf interval
X=sprintf('Tinti & Gasperini non neg  16 %f %f %i %f %f %f %f %i %f',b3ept,erb3ept,nnppe,pp3ept,b3ept-bx1v3bpe,bx2v3bpe-b3ept,(bx2v3bpe-bx1v3bpe)/2);
disp(X)
% mean b-value, std b-value, mean n data, p,  lower conf interval, upper conf interval, mean conf interval
X=sprintf('Tinti & Gasperini non neg  17 %f %f %i %f %f %f %f %i %f',b3tp,erb3tp,nnpp,pp3tp,b3tp-bx1v3bp,bx2v3bp-b3tp,(bx2v3bp-bx1v3bp)/2);
disp(X)
taber3(5,1)=bve;
taber3(5,2)=16;
taber3(5,3)=nnnne;
taber3(5,4)=b3ent;
taber3(5,5)=erb3ent;
taber3(5,6)=b3ent-bx1v3bne;
taber3(5,7)=bx2v3bne-b3ent;
taber3(5,8)=(bx2v3bne-bx1v3bne)/2;
taber3(6,1)=bve;
taber3(6,2)=17;
taber3(6,3)=nnnn;
taber3(6,4)=b3tn;
taber3(6,5)=erb3tn;
taber3(6,6)=b3tn-bx1v3bn;
taber3(6,7)=bx2v3bn-b3tn;
taber3(6,8)=(bx2v3bn-bx1v3bn)/2;
% mean b-value, std b-value, mean n data, p,  lower conf interval, upper conf interval, mean conf interval
X=sprintf('Tinti & Gasperini non pos  16 %f %f %i %f %f %f %f %i %f',b3ent,erb3ent,nnnne,pp3ent,b3ent-bx1v3bne,bx2v3bne-b3ent,(bx2v3bne-bx1v3bne)/2);
disp(X)
% mean b-value, std b-value, mean n data, p,  lower conf interval, upper conf interval, mean conf interval
X=sprintf('Tinti & Gasperini non pos  17 %f %f %i %f %f %f %f %i %f',b3tn,erb3tn,nnnn,pp3tn,b3tn-bx1v3bn,bx2v3bn-b3tn,(bx2v3bn-bx1v3bn)/2);
disp(X)
tab(5,1)=b3et;
tab(5,2)=erb3et;
tab(5,3)=nne;
tab(5,4)=pp3et;
tab(6,1)=b3t;
tab(6,2)=erb3t;
tab(6,3)=nn;
tab(6,4)=pp3t;
tab1(5,1)=b3t;
tab1(5,2)=erb3t;
tab1(5,3)=nn;
tab1(5,4)=pp3t;
tab2(5,1)=b3t;
tab2(5,2)=erb3t;
tab2(5,3)=nn;
tab2(5,4)=pp3t;
tab2e(5,1)=b3t;
tab2e(5,2)=erb3t;
tab2e(5,3)=nn;
tab2e(5,4)=pp3t;
function f=fun(x)
global beta amu sigm
f=-(beta.*exp(-beta.*x).*normcdf((x-amu)./sigm))./exp(-amu.*beta+(beta.^2.*sigm.^2)/2);
end
function f=bender(bval)
global bin nk sum
beta=bval*log(10);
q=exp(-beta*bin);
f=abs(q/(1-q)-nk*q^nk/(1-q^nk)-sum);
end
