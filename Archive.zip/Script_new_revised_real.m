% AGU PUBBLICATIONS
% Geophysical Journal International
% Supporting information for 
% The estimation of b-value of the frequency-magnitude distribution and of its one-sigma intervals from binned magnitude data
% S. Tinti1, P. Gasperini1,2
% 1 Dipartimento di Fisica e Astronomia "Augusto Righi", Università di Bologna, Italy
% 2 Istituto Nazionale di Geofisica e Vulcanologia, Sezione di Bologna, Italy
%
clear all
close all
global beta amu sigm bin nk sum
bin=0.1; % binning size
del=bin/2; % half of the binning size
cto=bin; % minimum magnitude difference in trimmed sets

nds=0;
nnpos=0;
nneg=0;
ams=0;
m=csvread("Norcia.csv",1);
%amwv(:)=fix(m(:,10)./bin).*bin;
amwv(:)=m(:,10);
nr1=length(amwv);
amc= min(amwv)

% Bender (1983)
    kk=fix((amwv-amc)./bin+0.0001);
    nk=max(kk)-min(kk)+1;
    xkk=zeros(nk);
    for j=1:nr1
        xkk(kk(j)+1)=xkk(kk(j)+1)+1;
        ams=ams+amwv(j);
    end
    sum=0;
    for j=1:nk
       sum=sum+(j-1)*xkk(j);
    end
    sum=sum/nr1;
    warning off
    [bval]=fminunc(@bender,1);
    warning on
    nr=nr1
    ams=ams/nr1 % mean magnitude
    bend=bval % b-value using Bender (1983) approach
    aki=1/(log(10)*(ams-amc)) % b-value using Aki (1965) formula 
    akiutsu=1/(log(10)*(ams-amc+del)) % b-value using Aki (1965) formula with Utsu( 1966) correction
    betam=1/(ams-amc+del);
    marzocchi=1/log(10)/2/del*log((1+betam*del)/(1-betam*del)) % b-value using Marzocchi et al. (2020) correction
    vde=1/log(10)/del*atanh(1/((ams-amc+del)/del)) % b-value using van der Elst (2021) formula for magnitudes
    TinGas=1/log(10)/2/del*log((ams-amc+2*del)/(ams-amc)) % b-value Tinti and Gasperini (2022) formula for magnitudes
    eraki=aki/sqrt(nr) % error using Aki (1965) formula 
    sfm=0.;
    for jj=1:nr
        sfm=sfm+(ams-amwv(jj))^2;        
    end
    av=exp(log(10)*TinGas*bin);
    bx1v=log((av+sqrt(av/nr1))/(1+sqrt(av/nr1)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for b-value using Tinti and Gasperini (20221) formula for magnitudes
    bx2v=log((av-sqrt(av/nr1))/(1-sqrt(av/nr1)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for b-value using Tinti and Gasperini (20221) formula for magnitudes
    erbxx=(bx2v-bx1v)/2;
    erbbv=2.30*TinGas^2*sqrt(sfm/nr/(nr-1)); % error using Shi and Bolt (1982) formula for b-value using Tinti and Gasperini (20221) formula for magnitudes
    amaxx=max(amwv);
    an=0;
    nd=0;
    ad=0;
    np=0;
    ap=0;
    nn=0;
    ane=0;
    nde=0;
    ade=0;
    npe=0;
    ape=0;
    nne=0;
    ane=0;
    ann=0;
    nnn=0;
    anne=0;
    nnne=0;
    anp=0;
    annn=0;
    anpe=0;
    annne=0;
    nnpp=0;
    nnnn=0;
    nnppe=0;
    nnnne=0;
    nnpose=0;
    nnege=0;
    sumd=0;
    nsumd=0;
    nr2=nr/2;
    for i=1:nr2
        d=amwv(2*i)-amwv(2*i-1); % independent differences
        sumd=sumd+d;
        nsumd=nsumd+1;
        if abs(d)>=cto-0.0001 % trimming (corrected for rounding)
           ad=ad+abs(d); % trimmed absolute differences
           nd=nd+1;
           if d>0
              ap=ap+d; % trimmed positive differences
              np=np+1;
           end
           if d<0
              ann=ann+abs(d); % trimmed negative differences
              nnn=nnn+1;
           end
        end
        an=an+abs(d); % untrimmed absolute differences
        nn=nn+1;
        dv(nn)=abs(d);
        if(d>=0)
           anp=anp+d; % untrimmed non negative differences
           nnpp=nnpp+1;
           nnpos=nnpos+1;
           dpos(nnpos)=d;
        end
        if(d<=0)
           annn=annn+abs(d); % untrimmed non positive difference
           nnnn=nnnn+1;
           nneg=nneg+1;
           dneg(nneg)=abs(d);
        end
    end
    for i=1:nr-1
       e=amwv(i+1)-amwv(i); % dependent differences
       if abs(e)>=cto-0.0001
          ade=ade+abs(e); % trimmed absolute differences
          nde=nde+1;
          if e>0
             ape=ape+e; % trimmed positive differences
             npe=npe+1;
             dpose(npe)=e;
          end
          if e<0
             anne=anne+abs(e); % trimmed negative differences
             nnne=nnne+1;
             dnege(nnne)=abs(e);
          end
       end
       ane=ane+abs(e); % untrimmed absolute differences
       nne=nne+1;
       ev(nne)=abs(e);
       if(e>=-0.00001)
           anpe=anpe+e; % untrimmed non negative differences
           nnppe=nnppe+1;
           nnpose=nnpose+1;
           dposue(nnpose)=e;
       end
       if(e<=0.00001)
          annne=annne+abs(e); % untrimmed non positive difference
          nnnne=nnnne+1;
          nnege=nnege+1;
          dnegue(nnege)=abs(e);
       end
    end
X=sprintf('Author             method         b      N      low       up  (low+up)/2');
disp(X)
% b-value from trimmed absolute differences according to van der Elst(2021) (independent)
    amd=ad/nd; % mean of trimmed absolute differences (independent)
    bval=1/log(10)/del*atanh(1/((amd-cto+del)/del)); 
    [low,up]=ertrim(bval,nd);
    X=sprintf('van der Elst      abs trim 17 %f %i %f %f %f',bval,nd,bval-low,up-bval,(up-low)/2);
    disp(X)
% b-value from trimmed absolute differences according to Tinti and Gasperini (2022) (independent)
    bval=1/log(10)/2/del*log((amd-cto+2*del)/(amd-cto)); 
    [low,up]=ertrim(bval,nd);
    X=sprintf('Tinti & Gasperini abs trim 17 %f %i %f %f %f',bval,nd,bval-low,up-bval,(up-low)/2);
    disp(X)
%    tabt(8,1)="";
%    tabt(8,2)="(19)";
%    tabt(8,3)="(17)";
    tabt(8,4)=nd;
    tabt(8,5)=bval;
    tabt(8,6)=bval-low;
    tabt(8,7)=up-bval;
    tabt(8,8)=(up-low)/2;
% b-value from trimmed positive differences according to Tinti and Gasperini (2022) (independent)
    amp=ap/np; % mean of trimmed positive differences (independent)
    bvalp=1/log(10)/2/del*log((amp-cto+2*del)/(amp-cto)); 
    [low,up]=ertrim(bvalp,np);
    varp=((up-low)/2)^2;
    X=sprintf('Tinti & Gasperini pos trim 17 %f %i %f %f %f',bvalp,np,bvalp-low,up-bvalp,(up-low)/2);
    disp(X)
%    tabt(10,1)="";
%    tabt(10,2)="(19)";
%    tabt(10,3)="(17)"
    tabt(10,4)=np;
    tabt(10,5)=bvalp;
    tabt(10,6)=bvalp-low;
    tabt(10,7)=up-bvalp;
    tabt(10,8)=(up-low)/2;
% b-value from trimmed negative differences according to Tinti and Gasperini (2022) (independent)
    amnn=ann/nnn; % mean of trimmed negative differences (independent)
    bvaln=1/log(10)/2/del*log((amnn-cto+2*del)/(amnn-cto)); 
    [low,up]=ertrim(bvaln,nnn);
    varn=((up-low)/2)^2;
    tt=abs(bvalp-bvaln)/sqrt(varp+varn);
    ddff=np+nnn;
    pp=tpdf(tt,ddff);
    X=sprintf('Tinti & Gasperini neg trim 17 %f %i %f %f %f %f %f',bvaln,nnn,bvaln-low, up-bvaln,(up-low)/2, tt, pp);
    disp(X)
%    tabt(12,1)="";
%    tabt(12,2)="(19)";
%    tabt(12,3)="(17)";
    tabt(12,4)=nnn;
    tabt(12,5)=bvaln;
    tabt(12,6)=bvaln-low;
    tabt(12,7)=up-bvaln;
    tabt(12,8)=(up-low)/2;
% b-value from trimmed absolute differences  according to Tinti and Gasperini (2022) (dependent)
    amde=ade/nde; % mean of trimmed absolute differences (dependent)
    bval=1/log(10)/2/del*log((amde-cto+2*del)/(amde-cto)); 
    [low,up]=ertrim(bval,nde);
    X=sprintf('Tinti & Gasperini abs trim 16 %f %i %f %f %f',bval,nde,bval-low,up-bval,(up-low)/2);
    disp(X)
%    tabt(7,1)="This paper, trimmed absolute differences";
%    tabt(7,2)="(19)";
%    tabt(7,3)="(16)";
    tabt(7,4)=nde;
    tabt(7,5)=bval;
    tabt(7,6)=bval-low;
    tabt(7,7)=up-bval;
    tabt(7,8)=(up-low)/2;
% b-value from trimmed positive differences according to Tinti and Gasperini (2022)(dependent)
    ampe=ape/npe; % mean of trimmed positive differences (dependent)
    bvalp=1/log(10)/2/del*log((ampe-cto+2*del)/(ampe-cto)); 
    [low,up]=ertrim(bvalp,npe);
    varp=((up-low)/2)^2;
    X=sprintf('Tinti & Gasperini pos trim 16 %f %i %f %f %f',bvalp,npe,bvalp-low,up-bvalp,(up-low)/2);
    disp(X)
%    tabt(9,1)="This paper, trimmed positive differences";
%    tabt(9,2)="(19)";
%    tabt(9,3)="(16)";
    tabt(9,4)=npe;
    tabt(9,5)=bvalp;
    tabt(9,6)=bvalp-low;
    tabt(9,7)=up-bvalp;
    tabt(9,8)=(up-low)/2;
    bvalok=bvalp;
% b-value from trimmed negative differences according to Tinti and Gasperini (2022)(dependent)
    amnne=anne/nnne; % mean of trimmed negative differences (dependent)
    bvaln=1/log(10)/2/del*log((amnne-cto+2*del)/(amnne-cto)); 
    [low,up]=ertrim(bvaln,nnne);
    varn=((up-low)/2)^2;
    tt=abs(bvalp-bvaln)/sqrt(varp+varn);
    ddff=npe+nnne;
    pp=tpdf(tt,ddff);
    X=sprintf('Tinti & Gasperini neg trim 16 %f %i %f %f %f %f %f',bvaln,nnne,bvaln-low,up-bvaln,(up-low)/2,tt,pp);
    disp(X)
 %   tabt(11,1)="This paper, trimmed negative differences";
 %   tabt(11,2)="(19)";
 %   tabt(11,3)="(16)";
    tabt(11,4)=nnne;
    tabt(11,5)=bvaln;
    tabt(11,6)=bvaln-low;
    tabt(11,7)=up-bvaln;
    tabt(11,8)=(up-low)/2;
% b-value from untrimmed absolute differences according to Tinti and Gasperini (2022) (independent)   
    amn=an/nn; % mean of untrimmed absolute differences (independent)
    bval=1/log(10)/del/2.*asinh(1/((amn)/del/2.));
    [low,up]=eruntr(bval,nn);
    X=sprintf('van der Elst      abs      17 %f %i %f %f %f',bval,nn,bval-low,up-bval,(up-low)/2);
    disp(X)    
    bval=1/log(10)/2/del*log((2*del+sqrt(4*del^2+amn^2))/amn); 
    [low,up]=eruntr(bval,nn);
    X=sprintf('Tinti & Gasperini abs      17 %f %i %f %f %f',bval,nn,bval-low,up-bval,(up-low)/2);
    disp(X)
%    tabt(2,1)="";
%    tabt(2,2)="(15)";
%    tabt(2,3)="(17)";
    tabt(2,4)=nn;
    tabt(2,5)=bval;
    tabt(2,6)=bval-low;
    tabt(2,7)=up-bval;
    tabt(2,8)=(up-low)/2;
% b-value from untrimmed non negative differences according to Tinti and Gasperini (2022) (independent)   
    amnpp=anp/nnpp; % mean of untrimmed not negative differences (independent)
    bvalp=1/log(10)/2/del*log((amnpp+2*del)/(amnpp));
    [low,up]=ertrim(bvalp,nnpp);
    varp=((up-low)/2)^2;
    X=sprintf('Tinti & Gasperini non neg  17 %f %i %f %f %f',bvalp,nnpp,bvalp-low,up-bvalp,(up-low)/2);
    disp(X)
%    tabt(4,1)="";
%    tabt(4,2)="(19)";
%    tabt(4,3)="(17)";
    tabt(4,4)=nnpp;
    tabt(4,5)=bvalp;
    tabt(4,6)=bvalp-low;
    tabt(4,7)=up-bvalp;
    tabt(4,8)=(up-low)/2;
% b-value from untrimmed non negative differences according to Tinti and Gasperini (2022) (independent)   
    amnnn=annn/nnnn; % mean of untrimmed non positive difference (independent)
    bvaln=1/log(10)/2/del*log((amnnn+2*del)/(amnnn));
    [low,up]=ertrim(bvaln,nnnn);
    varn=((up-low)/2)^2;
    tt=abs(bvalp-bvaln)/sqrt(varp+varn);
    ddff=nnpp+nnnn;
    pp=tpdf(tt,ddff);
    X=sprintf('Tinti & Gasperini non pos  17 %f %i %f %f %f %f %f',bvaln,nnnn,bvaln-low,up-bvaln,(up-low)/2,tt,pp);
    disp(X)
%    tabt(6,1)="";
%    tabt(6,2)="(19)";
%    tabt(6,3)="(17)";
    tabt(6,4)=nd;
    tabt(6,5)=bvaln;
    tabt(6,6)=bvaln-low;
    tabt(6,7)=up-bvaln;
    tabt(6,8)=(up-low)/2;
% b-value from untrimmed absolute differences according to Tinti and Gasperini (2022) (dependent)   
    amne=ane/nne; % mean of untrimmed absolute differences (dependent)
    bval=1/log(10)/2/del*log((2*del+sqrt(4*del^2+amne^2))/amne); 
    [low,up]=eruntr(bval,nne);
    X=sprintf('Tinti & Gasperini abs      16 %f %i %f %f %f',bval,nne,bval-low,up-bval,(up-low)/2);
    disp(X)
%    tabt(1,1)="This paper, absolute differences";
%    tabt(1,2)="(15)";
%    tabt(1,3)="(16)";
    tabt(1,4)=nne;
    tabt(1,5)=bval;
    tabt(1,6)=bval-low;
    tabt(1,7)=up-bval;
    tabt(1,8)=(up-low)/2;
% b-value from untrimmed non negative differences according to Tinti and Gasperini (2022) (dependent)   
    amnppe=anpe/nnppe; % mean of untrimmed not negative differences (dependent)
    bvalp=1/log(10)/2/del*log((amnppe+2*del)/(amnppe));
    [low,up]=ertrim(bvalp,nnppe);
    varp=((up-low)/2)^2;
    X=sprintf('Tinti & Gasperini non neg  16 %f %i %f %f %f',bvalp,nnppe,bvalp-low,up-bvalp,(up-low)/2);
    disp(X)
 %   tabt(3,1)="This paper, non negative differences";
 %   tabt(3,2)="(19)";
 %   tabt(3,3)="(16)";
    tabt(3,4)=nnppe;
    tabt(3,5)=bvalp;
    tabt(3,6)=bvalp-low;
    tabt(3,7)=up-bvalp;
    tabt(3,8)=(up-low)/2;
% b-value from untrimmed non positive differences according to Tinti and Gasperini (2022) (dependent)   
    amnnne=annne/nnnne; % mean of untrimmed non positive difference (dependent)
    bvaln=1/log(10)/2/del*log((amnnne+2*del)/(amnnne));
    [low,up]=ertrim(bvaln,nnnne);
    varn=((up-low)/2)^2;
    tt=abs(bvalp-bvaln)/sqrt(varp+varn);
    ddff=nnppe+nnnne;
    pp=tpdf(tt,ddff);
    X=sprintf('Tinti & Gasperini non pos  16 %f %i %f %f %f %f %f',bvaln,nnnne,bvaln-low,up-bvaln,(up-low)/2,tt,pp);
    disp(X)
%    tabt(5,1)="This paper, non positive differences";
%    tabt(5,2)="(19)";
%    tabt(5,3)="(16)";
    tabt(5,4)=nnnne;
    tabt(5,5)=bvaln;
    tabt(5,6)=bvaln-low;
    tabt(5,7)=up-bvaln;
    tabt(5,8)=(up-low)/2;
         beta=log(10)*bvalok;
         amu=2.5;
         sigm=0.32;
        figure
         xx=0:0.05 :8.05;
         yy=-(beta.*exp(-beta.*xx).*normcdf((xx-amu)./sigm))./exp(-amu.*beta+(beta.^2.*sigm.^2)/2);
         cor=nn/4;
         semilogy(xx,-yy.*cor)
        hold on
         zz=beta*exp(-beta.*xx)/(exp(-amu*beta+(beta^2*sigm^2)/2));
         plot(xx,zz.*cor)
         hold on
         xlabel('Magnitude','FontSize',14,'Fontweight','bold')
         ylabel('N','FontSize',14,'Fontweight','bold','Rotation',90)
         aa=-1.05:0.1:8.05;
         histogram(amwv,aa);
         figure
         hold off
         aa=-1.05:0.1:5.05;
         xx=0:0.05 :5;
         cor=nn/1100;
         zz=beta*exp(-beta.*xx)/(exp(-amu*beta+(beta^2*sigm^2)/2));
         semilogy(xx,zz.*cor)
         hold on
         xlabel('Magnitude difference','FontSize',14,'Fontweight','bold')
         ylabel('N','Rotation',90,'FontSize',14,'Fontweight','bold')
         histogram(ev,aa);
         nnplot=nn;
         hold off
function [f1,f2]=ertrim(bval,ndat)
     global bin
     alpha=exp(log(10)*bval*bin);
     f1=log((alpha+sqrt(alpha/ndat))/(1+sqrt(alpha/ndat)))/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for trimmed absolute differences according to Tinti and Gasperini (2022
     f2=log((alpha-sqrt(alpha/ndat))/(1-sqrt(alpha/ndat)))/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for trimmed absolute differences according to Tinti and Gasperini (2022
end
function [f1,f2]=eruntr(bval,ndat)
     global bin
     alpha=log(10)*bval*bin;
     cschalp=csch(alpha)*(1+sqrt(cosh(alpha)/ndat));
     cschalm=csch(alpha)*(1-sqrt(cosh(alpha)/ndat));
     f1=log((1+sqrt(1+cschalp^2))/cschalp)/log(10)/bin; % upper confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
     f2=log((1+sqrt(1+cschalm^2))/cschalm)/log(10)/bin; % lower confidence limit according to Tinti and Gasperini (2022) for untrimmed absolute differences (dependent) according to Tinti and Gasperini (2022)
end
 function f=fun(x)
 global beta amu sigm
 f=-(beta.*exp(-beta.*x).*normcdf((x-amu)./sigm))./exp(-amu.*beta+(beta.^2.*sigm.^2)/2);
 end
function f=bender(bval)
global bin nk sum
beta=bval*log(10);
q=exp(-beta*bin);
f=abs(q/(1-q)-nk*q^nk/(1-q^nk)-sum);
end
